package sample.classes;

public class Settings {

    private String title;

    public Settings(String title) {
        this.title = title;
    }
}
